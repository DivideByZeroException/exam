﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exam
{
    public partial class ExamApp : Form
    {
        string date_time;
        DateTime start_date;
        string[] temps;
        
        string fish_name;
        string[] max_temp;
        bool mistakes = false;
        string[] min_temp;
        DateTime current_date;
        string temp;
        DateTime limit = new DateTime(2000,1,1,0,0,0);
        DateTime minlimit = new DateTime(2000, 1, 1, 0, 0, 0);
        DateTime maxlimit = new DateTime(2000, 1, 1, 0, 0, 0);
        public ExamApp()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        { 
            openDialog.ShowDialog();
            string filename = openDialog.FileName;
            StreamReader sw = null;
            try
            {
                sw = new StreamReader(filename, false);
                 
                date_time = sw.ReadLine();
                start_date = DateTime.Parse(date_time);
                current_date = start_date;
                

                temps = sw.ReadLine().Split(" ");
                temp = "";
                foreach (var t in temps)
                {
                    temp = temp + t + " ";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Ошибка ввода данных");
            }
            finally
            {
                sw.Close();   
            }
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            openDialog.ShowDialog();
            string filename = openDialog.FileName;
            StreamReader sw = null;
            try
            {
                sw = new StreamReader(filename, false);
                fish_name = sw.ReadLine();
                max_temp = sw.ReadLine().Split(" ");
                string min_temp_line = sw.ReadLine();
                if (min_temp_line == null)
                {
                    min_temp = null;
                }
                else
                {
                    min_temp = min_temp_line.Split(" ");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Ошибка ввода данных");
            }
            finally
            {
                sw.Close();
            }
        }

        private void confirm_Click(object sender, EventArgs e)
        {
            save.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            save.ShowDialog();
            string filename = save.FileName;
            mistakes = false;
            limit = new DateTime(2000, 1, 1, 0, 0, 0);
            minlimit = new DateTime(2000, 1, 1, 0, 0, 0);
            maxlimit = new DateTime(2000, 1, 1, 0, 0, 0);
            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter("max.txt", false);
                sw.WriteLine("Рыба " + fish_name);
                sw.WriteLine("Максимальная температура " + max_temp[0] +" срок хранения "+ max_temp[1]);
                if (min_temp != null)
                {
                    sw.WriteLine("Минимальная температура " + min_temp[0]+ " срок хранения " + max_temp[1]);
                }
                sw.WriteLine("Дата начала измерений "+start_date);
                sw.WriteLine("Температуры "+temp);          
                for (int i = 0; i < temps.Length; i++)
                {
                    if(min_temp != null)
                    {
                        if (Convert.ToInt32(temps[i]) < Convert.ToInt32(min_temp[0]))
                        {
                            sw.WriteLine($"{current_date:g}" + " " + temps[i] + " "+min_temp[0]+" " + (Convert.ToInt32(min_temp[0]) - Convert.ToInt32(temps[i]) ) + " (превышение минимальной температуры)");
                            limit = limit.AddMinutes(10);
                            minlimit = minlimit.AddMinutes(10);
                        }
                        else if (Convert.ToInt32(temps[i])> Convert.ToInt32(max_temp[0]))
                        {
                           sw.WriteLine($"{current_date:g}" + " " + temps[i] + " " + max_temp[0] + " " + (Convert.ToInt32(temps[i]) - Convert.ToInt32(max_temp[0])  )+" (превышение максимальной температуры)");
                           limit = limit.AddMinutes(10);
                           maxlimit = maxlimit.AddMinutes(10);
                        }
                    }
                    else
                    {
                        if (Convert.ToInt32(temps[i]) > Convert.ToInt32(max_temp[0]))
                        {
                            sw.WriteLine($"{current_date:g}" + " " + temps[i] + " " + max_temp[0] + " " + (Convert.ToInt32(temps[i]) - Convert.ToInt32(max_temp[0])) + " (превышение максимальной температуры)");
                            limit = limit.AddMinutes(10);
                            maxlimit = maxlimit.AddMinutes(10);
                        }
                    }
                    current_date = current_date.AddMinutes(10);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (sw != null)
                {
                    sw.WriteLine("Повышение порога в течении " + $"{limit:t}");
                    if (min_temp != null)
                    {
                        string max_temp_minutes = Convert.ToString(maxlimit.Hour * 60 + maxlimit.Minute);
                        string min_temp_minutes = Convert.ToString(minlimit.Hour * 60 + minlimit.Minute);
                        if (Convert.ToInt32(max_temp_minutes) > 0)
                        {
                            sw.WriteLine("Превышение максимальной температуры в течении "+max_temp_minutes+" минут");
                            if (Convert.ToInt32(max_temp_minutes) > Convert.ToInt32(max_temp[1]))
                            {
                                sw.WriteLine("Нарушение условий хранения! Максимально допустимое время хранения при температуре " + max_temp[0] + " " + max_temp[1] + " минут. Рыба лежала в худших условиях на " + (Convert.ToInt32(max_temp_minutes) - Convert.ToInt32(max_temp[1])) + " минут дольше!");
                                mistakes = true;
                            }
                        }
                        if (Convert.ToInt32(min_temp_minutes) > 0)
                        {
                            sw.WriteLine("Превышение минимальной температуры в течении " + min_temp_minutes + " минут");
                            if (Convert.ToInt32(min_temp_minutes) > Convert.ToInt32(min_temp[1]))
                            {
                                sw.WriteLine("Нарушение условий хранения! Максимально допустимое время хранения при температуре " + min_temp[0] + " " + min_temp[1] + " минут. Рыба лежала в худших условиях на " + (Convert.ToInt32(min_temp_minutes) - Convert.ToInt32(min_temp[1])) + " минут дольше!");
                                mistakes = true;
                            }
                        }
                    }
                    else
                    {
                        string max_temp_minutes = Convert.ToString(maxlimit.Hour * 60 + maxlimit.Minute);
                        if (Convert.ToInt32(max_temp_minutes) > 0)
                        {
                            sw.WriteLine("Превышение максимальной температуры в течении " + max_temp_minutes + " минут");
                            if (Convert.ToInt32(max_temp_minutes) > Convert.ToInt32(max_temp[1]))
                            {
                                sw.WriteLine("Нарушение условий хранения! Максимально допустимое время хранения при температуре " + max_temp[0] + " " + max_temp[1] + " минут. Рыба лежала в худших условиях на " + (Convert.ToInt32(max_temp_minutes) - Convert.ToInt32(max_temp[1])) + " минут дольше!");
                                mistakes = true;
                            }
                        }

                    }
                }
                if (mistakes)
                {
                    sw.WriteLine();
                    sw.WriteLine("ИМЕЮТСЯ НАРУШЕНИЯ!");
                    MessageBox.Show("Имеются нарушения!");
                }
                sw.Close();
                System.IO.File.WriteAllText(filename, System.IO.File.ReadAllText("max.txt"));
                System.Diagnostics.Process txt = new System.Diagnostics.Process();
                txt.StartInfo.FileName = "notepad.exe";
                txt.StartInfo.Arguments = filename;
                txt.Start();

            }
        }
        private void ok_Click(object sender, EventArgs e)
        {
            try
            {
                date_time = calendar.Text;
                start_date = DateTime.Parse(date_time);
                current_date = start_date;
                temps = dont_file_temps.Text.Split(" ");
                temp = "";
                foreach (var t in temps)
                {
                    temp = temp + t + " ";
                }
            }
            catch
            {
                MessageBox.Show("Ошибка ввода данных");
            }
        }
    }
}
