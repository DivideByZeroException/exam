﻿
namespace exam
{
    partial class ExamApp
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openDialog = new System.Windows.Forms.OpenFileDialog();
            this.open_file = new System.Windows.Forms.Button();
            this.open_text = new System.Windows.Forms.Label();
            this.openStats = new System.Windows.Forms.OpenFileDialog();
            this.open_second_file = new System.Windows.Forms.Button();
            this.fish_info = new System.Windows.Forms.Label();
            this.confirm = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.SaveFileDialog();
            this.dont_file_temps = new System.Windows.Forms.TextBox();
            this.temp_dont_auto = new System.Windows.Forms.Label();
            this.ok = new System.Windows.Forms.Button();
            this.calendar_text = new System.Windows.Forms.Label();
            this.calendar = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // openDialog
            // 
            this.openDialog.FileName = "openFileDialog1";
            // 
            // open_file
            // 
            this.open_file.Location = new System.Drawing.Point(47, 41);
            this.open_file.Name = "open_file";
            this.open_file.Size = new System.Drawing.Size(131, 45);
            this.open_file.TabIndex = 0;
            this.open_file.Text = "Открыть файл";
            this.open_file.UseVisualStyleBackColor = true;
            this.open_file.Click += new System.EventHandler(this.button1_Click);
            // 
            // open_text
            // 
            this.open_text.AutoSize = true;
            this.open_text.Location = new System.Drawing.Point(25, 13);
            this.open_text.Name = "open_text";
            this.open_text.Size = new System.Drawing.Size(182, 15);
            this.open_text.TabIndex = 1;
            this.open_text.Text = "Загрузить значения температур";
            // 
            // openStats
            // 
            this.openStats.FileName = "openFileDialog1";
            // 
            // open_second_file
            // 
            this.open_second_file.Location = new System.Drawing.Point(47, 130);
            this.open_second_file.Name = "open_second_file";
            this.open_second_file.Size = new System.Drawing.Size(131, 45);
            this.open_second_file.TabIndex = 2;
            this.open_second_file.Text = "Открыть файл";
            this.open_second_file.UseVisualStyleBackColor = true;
            this.open_second_file.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // fish_info
            // 
            this.fish_info.AutoSize = true;
            this.fish_info.Location = new System.Drawing.Point(25, 107);
            this.fish_info.Name = "fish_info";
            this.fish_info.Size = new System.Drawing.Size(182, 15);
            this.fish_info.TabIndex = 3;
            this.fish_info.Text = "Загрузить информацию о рыбе";
            // 
            // confirm
            // 
            this.confirm.Location = new System.Drawing.Point(47, 192);
            this.confirm.Name = "confirm";
            this.confirm.Size = new System.Drawing.Size(131, 70);
            this.confirm.TabIndex = 4;
            this.confirm.Text = "OK";
            this.confirm.UseVisualStyleBackColor = true;
            this.confirm.Click += new System.EventHandler(this.confirm_Click);
            // 
            // dont_file_temps
            // 
            this.dont_file_temps.Location = new System.Drawing.Point(222, 142);
            this.dont_file_temps.Name = "dont_file_temps";
            this.dont_file_temps.Size = new System.Drawing.Size(225, 23);
            this.dont_file_temps.TabIndex = 5;
            // 
            // temp_dont_auto
            // 
            this.temp_dont_auto.AutoSize = true;
            this.temp_dont_auto.Location = new System.Drawing.Point(253, 107);
            this.temp_dont_auto.Name = "temp_dont_auto";
            this.temp_dont_auto.Size = new System.Drawing.Size(152, 15);
            this.temp_dont_auto.TabIndex = 7;
            this.temp_dont_auto.Text = "Ручной ввод температуры";
            // 
            // ok
            // 
            this.ok.Location = new System.Drawing.Point(266, 192);
            this.ok.Name = "ok";
            this.ok.Size = new System.Drawing.Size(139, 70);
            this.ok.TabIndex = 8;
            this.ok.Text = "Сохранить ручной ввод";
            this.ok.UseVisualStyleBackColor = true;
            this.ok.Click += new System.EventHandler(this.ok_Click);
            // 
            // calendar_text
            // 
            this.calendar_text.AutoSize = true;
            this.calendar_text.Location = new System.Drawing.Point(295, 13);
            this.calendar_text.Name = "calendar_text";
            this.calendar_text.Size = new System.Drawing.Size(74, 15);
            this.calendar_text.TabIndex = 9;
            this.calendar_text.Text = "Выбрат дату";
            // 
            // calendar
            // 
            this.calendar.Location = new System.Drawing.Point(253, 41);
            this.calendar.Name = "calendar";
            this.calendar.Size = new System.Drawing.Size(152, 23);
            this.calendar.TabIndex = 10;
            // 
            // ExamApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(467, 293);
            this.Controls.Add(this.calendar);
            this.Controls.Add(this.calendar_text);
            this.Controls.Add(this.ok);
            this.Controls.Add(this.temp_dont_auto);
            this.Controls.Add(this.dont_file_temps);
            this.Controls.Add(this.confirm);
            this.Controls.Add(this.fish_info);
            this.Controls.Add(this.open_second_file);
            this.Controls.Add(this.open_text);
            this.Controls.Add(this.open_file);
            this.Name = "ExamApp";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openDialog;
        private System.Windows.Forms.Button open_file;
        private System.Windows.Forms.Label open_text;
        private System.Windows.Forms.OpenFileDialog openStats;
        private System.Windows.Forms.Button open_second_file;
        private System.Windows.Forms.Label fish_info;
        private System.Windows.Forms.Button confirm;
        private System.Windows.Forms.SaveFileDialog save;
        private System.Windows.Forms.TextBox dont_file_temps;
        private System.Windows.Forms.Label temp_dont_auto;
        private System.Windows.Forms.Button ok;
        private System.Windows.Forms.Label calendar_text;
        private System.Windows.Forms.TextBox calendar;
    }
}

